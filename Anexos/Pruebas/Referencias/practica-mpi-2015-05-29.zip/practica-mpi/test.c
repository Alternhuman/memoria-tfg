#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include "test.h"



double mygettime(void) {
  struct timeval tv;
  if(gettimeofday(&tv, 0) < 0) {
    perror("oops");
  }
  return (double)tv.tv_sec + (0.000001 * (double)tv.tv_usec);
}

// Numeros de 0 a NUM_MAX
void busca_numero(unsigned int numero, unsigned long long * intentos, double * tpo)
{
	short bSalir=0;
	double t1,t2;

	*intentos=0;

	t1=mygettime();	

	srand(1);

	do
	{
		(*intentos)++;
		if ((rand()%NUM_MAX+1)==numero)
			bSalir=1;

		//printf("%llu\n",*intentos);
	} while (!bSalir);		

	t2=mygettime();

	*tpo=t2-t1;
}


