#include "mpi.h"
#include <stdio.h>

long Obten_Dato_Maximo();
long Suma(long num1,long num2);

int main(int argc,char** argv){
	int id,numprocs,i;
	long ulValorMaximo,ulIntervalo;
	double tmpinic=0.0;
	double tmpfin;
	int etiqueta;
	long ulSuma;
	long ulSumaTotal=0;
	MPI_Status status;


	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&id);
	MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
	
	if(id==0) ulValorMaximo=Obten_Dato_Maximo();

	tmpinic=MPI_Wtime();
	if(id==0){
		ulIntervalo=ulValorMaximo/numprocs;
		etiqueta=15;

		for(i=1;i<numprocs;i++){
			MPI_Send(&ulIntervalo,1,MPI_UNSIGNED_LONG,i,etiqueta,MPI_COMM_WORLD);
		}
	}else{
		etiqueta=15;
		MPI_Recv(&ulIntervalo,1,MPI_UNSIGNED_LONG,0,etiqueta,MPI_COMM_WORLD,&status);
	}
	
	ulSuma=Suma(id*ulIntervalo+1,id*ulIntervalo+ulIntervalo);
	if(id==0){
		ulSumaTotal+=ulSuma;
		etiqueta=15;
		fprintf(stdout,"Nodo %d: %ld\n",id,ulSuma);

		for(i=1;i<numprocs;i++){
			MPI_Recv(&ulSuma,1,MPI_UNSIGNED_LONG,i,etiqueta,MPI_COMM_WORLD,&status);
			ulSumaTotal+=ulSuma;
			fprintf(stdout,"Nodo %d: %ld\n",i,ulSuma);
		}
	}else{
		etiqueta=15;
		MPI_Send(&ulSuma,1,MPI_UNSIGNED_LONG,0,etiqueta,MPI_COMM_WORLD);
	}
	tmpfin=MPI_Wtime();

	MPI_Finalize();

	return 0;
}

long Obten_Dato_Maximo(){
	long dato;

	scanf("%ld",&dato);

	return dato;
}

long Suma(long num1,long num2){
	long total=0;
	long i;
	for(i=num1;i<=num2;i++) total+=i;
	return total;
}
