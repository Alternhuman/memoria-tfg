#include <mpi.h>
#include <stdio.h>
//#include "busca.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "test.h"
//libreria mpi.h
#include <mpi.h>

#define CUANTOS 20

/*unsigned int lista[CUANTOS]= {
	1254,12255,1478,5487,50699,80775,12540,25148,96042,54125,
	12,13255,14282,54387,95699,87375,12549,2548,96602,54125,
	124,12455,24782,52487,85699,87475,12548,21548,96942,52125,
	154,12555,14278,54817,75699,87675,12547,12548,96842,54425,
	254,12565,14728,54287,65699,87785,12546,25418,96642,54155,
	2254,12755,14782,54487,55699,87775,12351,25148,95642,54525,
	3254,12855,42728,54867,45699,87975,12531,12548,94642,54425,
	4254,19255,24278,58487,35699,80775,12521,22548,93642,54325,
	5254,10255,22478,54897,25699,8775,22541,32548,91642,54145,
	6254,12055,21478,54807,15699,8775,12541,42548,92642,54135};*/

	unsigned int lista[CUANTOS]= {
	1254,12255,1478,5487,50699,80775,12540,25148,96042,54125,
	12,13255,14282,54387,95699,87375,12549,2548,96602,54125};

typedef struct retorno{
	int valor;
	unsigned long long intentos;
	double tiempo;
}retorno;

typedef struct limites{
	int inicio;
	int fin;
}limites;

double mygettime(void) {
  struct timeval tv;
  if(gettimeofday(&tv, 0) < 0) {
    perror("oops");
  }
  return (double)tv.tv_sec + (0.000001 * (double)tv.tv_usec);
}

void busca_numero(unsigned int numero, unsigned long long * intentos, double * tpo)
{
	short bSalir=0;
	double t1,t2;

	*intentos=0;

	t1=mygettime();	

	srand(1);

	do
	{
		(*intentos)++;
		if ((rand()%NUM_MAX+1)==numero)
			bSalir=1;

		//printf("%llu\n",*intentos);
	} while (!bSalir);		

	t2=mygettime();

	*tpo=t2-t1;
}


void tipo(limites *datos, MPI_Datatype *tipoMPI){
		MPI_Datatype tipos[2];
		int longitudes[2];
		MPI_Aint direcciones[3];
		MPI_Aint desplazamiento[2];

		tipos[0] = MPI_INT;
		tipos[1] = MPI_INT;

		longitudes[0] = 1;
		longitudes[1] = 1;

		MPI_Address(datos, &direcciones[0]);
		MPI_Address(&(datos->inicio), &direcciones[1]);
		MPI_Address(&(datos->fin), &direcciones[2]);
		desplazamiento[0] = direcciones[1] - direcciones[0];
		desplazamiento[1] = direcciones[2] - direcciones[0];
		
		MPI_Type_struct(2, longitudes, desplazamiento, tipos, tipoMPI);

		MPI_Type_commit(tipoMPI);
}

void tipoLongLong(retorno *datos, MPI_Datatype *tipoMPI){ 
//TODO: cambiar nombre
		MPI_Datatype tipos[3];
		int longitudes[3];
		MPI_Aint direcciones[4];
		MPI_Aint desplazamiento[3];

		tipos[0] = MPI_INT;
		tipos[1] =  MPI_UNSIGNED_LONG_LONG;
		tipos[2] = MPI_DOUBLE;

		longitudes[0] = 1;
		longitudes[1] = 1;
		longitudes[2] = 1;

		MPI_Address(datos, &direcciones[0]);
		MPI_Address(&(datos->valor), &direcciones[1]);
		MPI_Address(&(datos->intentos), &direcciones[2]);
		MPI_Address(&(datos->tiempo), &direcciones[3]);
		desplazamiento[0] = direcciones[1] - direcciones[0];
		desplazamiento[1] = direcciones[2] - direcciones[0];
		desplazamiento[2]= direcciones[3] - direcciones[0];
		
		MPI_Type_struct(3, longitudes, desplazamiento, tipos, tipoMPI);

		MPI_Type_commit(tipoMPI);
}

int main (int argc , char **argv){
	
	MPI_Init(&argc, &argv);
	int dato = 10;
	int numprocs;
	int recibido;
	int numerocalc;
	MPI_Status status;
	int i, j;

	int id;
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	MPI_Datatype MPI_LIM;
	MPI_Datatype MPI_RET;
	numerocalc = numprocs - 1;

	limites prueba;
	limites recibida;
	retorno ret;
	/*prueba.inicio = 10;
	prueba.fin = 20;*/

	tipo(&prueba, &MPI_LIM);
	tipoLongLong(&ret, &MPI_RET);
	unsigned long long  intentos;
	double tiempo;
	int reparto, resto;
	int tamanno;

	if(id==0){
		if(numerocalc >= CUANTOS){
			for (j = 0; j < CUANTOS; j++)
			{
				prueba.inicio =	prueba.fin = j;
				MPI_Send(&prueba, 1, MPI_LIM, j+1, 10, MPI_COMM_WORLD);
			}

			for(j = CUANTOS; j < numerocalc; j++){
				prueba.inicio = prueba.fin = -1;
				MPI_Send(&prueba, 1, MPI_LIM, j+1, 10, MPI_COMM_WORLD);
			}
		
			for (j = 0; j < CUANTOS; j++)
			{
				MPI_Recv(&ret,1,MPI_RET,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
				printf("%d, %ld, %lf\n", ret.valor, ret.intentos, ret.tiempo);
			}
		}else{
			puts("Hello!");
			reparto = CUANTOS / numerocalc;
			resto = CUANTOS % numerocalc;
			prueba.inicio = prueba.fin = 0;
			for (i = 1; i < numerocalc; i++, resto--)
			{
				
				if(resto > 0){
					prueba.fin = CUANTOS + prueba.inicio + 1;
				}else{
					prueba.fin = CUANTOS + prueba.inicio;
				}
				MPI_Send(&prueba, 1, MPI_LIM, i, 10, MPI_COMM_WORLD);
				prueba.inicio = prueba.fin + 1;
				//resto--;
			}
			for (j = 0; j < CUANTOS; j++)
			{
				MPI_Recv(&ret,1,MPI_RET,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
				printf("%d, %ld, %lf\n", ret.valor, ret.intentos, ret.tiempo);
			}
		}
		//MPI_Send(&prueba, 1, MPI_LIM, 1, 10, MPI_COMM_WORLD);
	}else{
		MPI_Recv(&recibida,1,MPI_LIM,0,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
		
		/*if(recibida.inicio != -1){
			printf("%d\n", recibida.inicio);
		}*/
			tamanno = recibida.fin - recibida.inicio + 1;
		for (i = 0; i < tamanno; i++)
		{
			busca_numero(lista[i + recibida.inicio], &intentos, &tiempo);
			//printf("%d, %d, %lf\n", lista[recibida.inicio], intentos, tiempo);
			ret.valor = lista[i + recibida.inicio];
			ret.intentos = intentos;
			ret.tiempo = tiempo;
			MPI_Send(&ret, 1, MPI_RET, 0, 20, MPI_COMM_WORLD);
		}
	}
	
	MPI_Finalize();
	return 0;
}