#!/bin/sh
mpirun -np 3 excel -v
mpirun -np 5 excel -v
mpirun -np 10 excel -v
mpirun -np 15 excel -v
mpirun -np 20 excel -v
mpirun -np 30 excel -v
mpirun -np 50 excel -v
mpirun -np 70 excel -v
mpirun -np 90 excel -v
mpirun -np 120 excel -v
mpirun -np 150 excel -v
mpirun -np 200 excel -v