
// http://stackoverflow.com/questions/2550281/floating-point-vs-integer-calculations-on-modern-hardware

#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <limits.h>
#include <float.h>
#define NUM_MAX	500000000

double mygettime(void);
void busca_numero(unsigned int numero, unsigned long long * intentos, double * tpo);

